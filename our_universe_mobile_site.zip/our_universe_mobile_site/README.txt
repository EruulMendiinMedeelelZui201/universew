OUR UNIVERSE — MOBILE-FRIENDLY WEBSITE PACKAGE

Files:
- index.html: the website
- assets/sun.glb, earth.glb, blackhole.glb, sky.glb: 3D models

IMPORTANT: Because the models are loaded as separate files with fetch(), do not open index.html directly with file://. Upload the entire folder to a static web host (for example GitHub Pages, Netlify, or Cloudflare Pages), or run it through a local web server. Keep the assets folder beside index.html.

Mobile improvements included:
- Compact touch-first controls and responsive information panel
- Lower pixel ratio and less expensive antialiasing on mobile devices
- Reduced star, galaxy, asteroid-belt, and planet geometry complexity on mobile
- External GLB assets for separate caching and parallel loading
- Preserved original scene and fallback planets if a model fails

All external libraries (Three.js and Google Fonts) still require an internet connection.
